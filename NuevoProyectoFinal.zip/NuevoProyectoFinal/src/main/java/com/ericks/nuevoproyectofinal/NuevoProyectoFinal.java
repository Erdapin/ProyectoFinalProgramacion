/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.ericks.nuevoproyectofinal;

/**
 *
 * @author Erick
 */
public class NuevoProyectoFinal {
    public static boolean bdUsuariosLibreriaCreada = false;
    public static boolean bdUsuariosLibreriaGuardados = false;
    public static int cantidadUsuariosLibreria = 0;
    
    public static boolean bdUsuariosClientesCreada = false;
    public static boolean bdUsuariosClientesGuardados = false;
    public static int cantidadUsuariosClientes = 0;
    
    public static boolean bdUsuariosColaboradoreCreada = false;
    public static boolean bdUsuariosColaboradoreGuardados = false;
    public static int cantidadUsuariosColaboradore = 0;
    
    
    public static boolean bdUsuariosCatEmpleadoCreado = false;
    public static boolean bdUsuariosCatEmpleadoGuardados = false;
    public static int cantidadUsuariosCatEmpleado = 0;
    
    public static boolean bdUsuariosCatClientesCreado = false;
    public static boolean bdUsuariosCatClientesGuardados = false;
    public static int cantidadUsuariosCatClientes = 0;
    
    public static boolean bdUsuariosCatCategProductosCreado = false;
    public static boolean bdUsuariosCatCategProductosGuardados = false;
    public static int cantidadUsuariosCatCategProductos = 0;
    
    public static boolean bdUsuariosCatProductosCreado = false;
    public static boolean bdUsuariosCatProductosGuardados = false;
    public static int cantidadUsuariosCatProductos = 0;
    
    public static boolean bdFacturaCreado = false;
    public static boolean bdFacturaGuardados = false;
    public static int cantidadFactura = 0;
    
    public static void main(String[] args) {
        //Declaraciones 
        Utilities utl = new Utilities();
        int opcion = 0;
        clsUsuarios UsuariosLibreria[] = new clsUsuarios[0];
        clsUsuarios Clientes[] = new clsUsuarios[0];
        clsUsuarios Colaboradores[] = new clsUsuarios[0];
        clsCatalogoPersona CatEmpleados[] = new clsCatalogoPersona[0];
        clsCatalogoPersona CatClientes[] = new clsCatalogoPersona[0];
        clsCatalogoCategoriaProductos CatCategoria[] = new clsCatalogoCategoriaProductos[0];
        clsCatalogoProductos CatProductos[] = new clsCatalogoProductos[0];
        clsFacturas Facturas[] = new clsFacturas[0];
        String ingresos[] = new String[0];
        
        utl.ShowMsg("****Bienvenido a libreria El Tesoro del Saber*****");
        
        do{
            opcion = utl.InputInt("Que desea hacer? \n 1-Administrar Usuarios Libreria\n 2-Administrar Clientes"+
                    "\n3-Administrar Colaboradores \n4-Administrar Catalogo Empleado \n5-Administrar Catalogo Clientes "+
                    "\n 6-Administar Catalogo Categorias Productos \n 7-Administrar Catalogo Productos \n 8- Administrar Facturas \n 9-Imprimir Ingresos de el día."+
                    "\n 0-Salir");
            switch(opcion){
                case 1:
                    UsuariosLibreria = MenuUsuariosLibreria(UsuariosLibreria);
                    break;
                case 2:
                    Clientes = MenuUsuariosClientes(Clientes);
                    break;
                case 3:
                    Colaboradores = MenuUsuariosColaboradores(Colaboradores);
                    break;
                case 4:
                    CatEmpleados = MenuCatalogoEmpleados(CatEmpleados);
                    break;
                case 5:
                    CatClientes = MenuCatalogoClientes(CatClientes);
                    break;
                case 6:
                    CatCategoria = MenuCatalogoCatProductos(CatCategoria);
                    break;
                case 7:
                    CatProductos = MenuCatalogoProductos(CatProductos,CatCategoria);
                    break;
                case 8:
                    Facturas = MenuFacturas(Facturas , CatProductos, CatClientes, CatEmpleados);
                    break;
                case 9:
                    ingresos = ImprimirIngresosDia(Facturas,ingresos);
                    break;
                case 0:
                    break;
                default:
                    utl.ShowMsg("Error, el valor ingresado no es una opcion valida.");
                    break;       
            }
        }while(opcion != 0);
        
    }

    public static clsUsuarios[] MenuUsuariosLibreria(clsUsuarios[] Usuarios){
        Utilities utl = new Utilities();
        clsUsuarios clsUsuario = new clsUsuarios();
       
        int opcion = 0;
        
        do{
            opcion = utl.InputInt("Usuarios Libreria \n 1-Crear Base de datos \n 2- Agregar Usuario \n 3- Inactivar Usuario \n 4 - Consultar \n 0-Salir");
            switch(opcion){
                //CREAR
                case 1:
                    if(bdUsuariosLibreriaCreada == false){
                        Usuarios = clsUsuario.generarBDUsuarios();
                        bdUsuariosLibreriaCreada = true;
                    }else{
                        utl.ShowMsg("Error, la base de datos ya habia sido creada");
                    }
                    
                    break;
                    //AGREGAR
                case 2:
                    if(!bdUsuariosLibreriaCreada){ utl.ShowMsg("Error, la base de datos aun no existe"); return Usuarios; };
                    if(bdUsuariosLibreriaCreada){
                        if(cantidadUsuariosLibreria< Usuarios.length){
                            bdUsuariosLibreriaGuardados = clsUsuario.FillUsuariosDB(Usuarios, cantidadUsuariosLibreria);
                            if (bdUsuariosLibreriaGuardados) {
                                cantidadUsuariosLibreria++;
                                utl.ShowMsg("El usuario se agregó correctamente");
                            }
                        }else{utl.ShowMsg("Error, se a exedido el numero de datos en Base de datos");}
                    }
                    
                    break;
                    //INACTIVAR
                case 3:
                    if(!bdUsuariosLibreriaCreada){ utl.ShowMsg("Error, la base de datos aun no existe"); return Usuarios; };
                    if (cantidadUsuariosLibreria == 0) {
                        utl.ShowMsg("Debe agregar una persona");
                    }
                    else{
                        int mensj = clsUsuario.InactivarUsuario(Usuarios, cantidadUsuariosLibreria);
                         if (mensj == 0) {
                            utl.ShowMsg("Error al eliminar el usuario");
                        }else if(mensj == 1){
                            cantidadUsuariosLibreria--;
                            utl.ShowMsg("Se ha eliminado el usuario.");
                            
                        }else
                            utl.ShowMsg("No se encontró el usuario");       
                    }
                    break;
                    //Consultar
                case 4:
                    if(bdUsuariosLibreriaCreada && cantidadUsuariosLibreria>0){
                        clsUsuario.VerTodosUsuarios( Usuarios , cantidadUsuariosLibreria);
                    }else{
                        utl.ShowMsg("Error, aun no hay usuarios o base de datos");
                    }
                    break;
                case 0:
                    break;
                default:
                    utl.ShowMsg("Error, el valor ingresado no es una opcion valida.");
                    break;       
            }
        }while(opcion != 0);
        
        return Usuarios;
    }
    public static clsUsuarios[] MenuUsuariosClientes(clsUsuarios[] Usuarios){
        Utilities utl = new Utilities();
        clsUsuarios clsUsuario = new clsUsuarios();
       
        int opcion = 0;
        
        do{
            opcion = utl.InputInt("Usuarios Clientes \n 1-Crear Base de datos \n 2- Agregar Cliente \n 3- Editar Cliente \n 4- Inactivar Cliente \n 0-Salir");
            switch(opcion){
                //CREAR
                case 1:
                     if(bdUsuariosClientesCreada == false){
                        Usuarios = clsUsuario.generarBDUsuarios();
                        bdUsuariosClientesCreada = true;
                    }else{
                        utl.ShowMsg("Error, la base de datos ya habia sido creada");
                    }
                    break;
                    //AGREGAR
                case 2:
                    if(bdUsuariosClientesCreada){
                        if(cantidadUsuariosClientes< Usuarios.length){
                            bdUsuariosClientesGuardados = clsUsuario.FillUsuariosDB(Usuarios, cantidadUsuariosClientes);
                            if (bdUsuariosClientesGuardados) {
                                cantidadUsuariosClientes++;
                                utl.ShowMsg("El Cliente se agregó correctamente");
                            }
                        }else{utl.ShowMsg("Error, se a exedido el numero de datos en Base de datos");}
                    }
                    
                    break;
                    //EDITAR
                case 3:
                    if(!bdUsuariosClientesCreada){ utl.ShowMsg("Error, la base de datos aun no existe"); return Usuarios; };
                    if (cantidadUsuariosClientes == 0) {
                        utl.ShowMsg("Debe agregar una persona");
                    }
                    else{
                        int mensj = clsUsuario.InactivarUsuario(Usuarios, cantidadUsuariosClientes);
                         if (mensj == 0) {
                            utl.ShowMsg("Error al eliminar el Cliente");
                        }else if(mensj == 1){
                            cantidadUsuariosClientes--;
                            utl.ShowMsg("Se ha eliminado el Cliente.");
                            
                        }else
                            utl.ShowMsg("No se encontró el Cliente");       
                    }
                    break;
                    //INACTIVAR
                case 4:
                    if(bdUsuariosClientesCreada && cantidadUsuariosClientes>0){
                        clsUsuario.VerTodosUsuarios( Usuarios , cantidadUsuariosClientes);
                    }else{
                        utl.ShowMsg("Error, aun no hay usuarios o base de datos");
                    }
                    break;
                case 0:
                    break;
                default:
                    utl.ShowMsg("Error, el valor ingresado no es una opcion valida.");
                    break;       
            }
        }while(opcion != 0);
        
        return Usuarios;
    }
    public static clsUsuarios[] MenuUsuariosColaboradores(clsUsuarios[] Usuarios){
        Utilities utl = new Utilities();
        clsUsuarios clsUsuario = new clsUsuarios();
       
        int opcion = 0;
        
        do{
            opcion = utl.InputInt("Usuarios Colaboradores \n 1-Crear Base de datos \n 2- Inactivar Colaborador \n 3- Editar Colaborador \n 4- Ver Colaborador \n 0-Salir");
            switch(opcion){
                //CREAR
                case 1:
                    if(bdUsuariosColaboradoreCreada == false){
                        Usuarios = clsUsuario.generarBDUsuarios();
                        bdUsuariosColaboradoreCreada = true;
                    }else{
                        utl.ShowMsg("Error, la base de datos ya habia sido creada");
                    }
                   
                    break;
                    //AGREGAR
                case 2:
                    if(bdUsuariosColaboradoreCreada){
                        if(cantidadUsuariosColaboradore< Usuarios.length){
                            bdUsuariosColaboradoreGuardados = clsUsuario.FillUsuariosDB(Usuarios, cantidadUsuariosColaboradore);
                            if (bdUsuariosColaboradoreGuardados) {
                                cantidadUsuariosColaboradore++;
                                utl.ShowMsg("El Colaborador se agregó correctamente");
                            }
                        }else{utl.ShowMsg("Error, se a exedido el numero de datos en Base de datos");}
                    }else{utl.ShowMsg("Error, la base de datos aun no a sido creada");}
                    
                    break;
                    //INACTIVAR
                case 3:
                    if(!bdUsuariosColaboradoreCreada){ utl.ShowMsg("Error, la base de datos aun no existe"); return Usuarios; };
                    if (cantidadUsuariosColaboradore == 0) {
                        utl.ShowMsg("Debe agregar un colaborador");
                    }
                    else{
                        int mensj = clsUsuario.InactivarUsuario(Usuarios, cantidadUsuariosColaboradore);
                         if (mensj == 0) {
                            utl.ShowMsg("Error al eliminar el colaborador");
                        }else if(mensj == 1){
                            cantidadUsuariosColaboradore--;
                            utl.ShowMsg("Se ha eliminado el colaborador.");
                            
                        }else
                            utl.ShowMsg("No se encontró el colaborador");       
                    }
                    break;
                    //Mostrar
                case 4:
                    if(bdUsuariosColaboradoreCreada && cantidadUsuariosColaboradore>0){
                        clsUsuario.VerTodosUsuarios( Usuarios , cantidadUsuariosColaboradore);
                    }else{
                        utl.ShowMsg("Error, aun no hay usuarios o base de datos");
                    }
                    break;
                case 0:
                    break;
                default:
                    utl.ShowMsg("Error, el valor ingresado no es una opcion valida.");
                    break;       
            }
        }while(opcion != 0);
        
        return Usuarios;
    }
    public static clsCatalogoPersona[] MenuCatalogoEmpleados(clsCatalogoPersona[] Usuarios){
        Utilities utl = new Utilities();
        clsCatalogoPersona clsUsuario = new clsCatalogoPersona();
       
        int opcion = 0;
        
        do{
            opcion = utl.InputInt("Catalogo Empleados \n 1-Crear Base de datos \n 2- Agregar Empleados \n 3- Editar Empleados \n 4- Inactivar Empleado \n 0-Salir");
            switch(opcion){
                //CREAR
                case 1:
                    if(bdUsuariosCatEmpleadoCreado == false){
                        Usuarios = clsUsuario.generarBDCatalogoPersona();
                        bdUsuariosCatEmpleadoCreado = true;
                    }else{
                        utl.ShowMsg("Error, la base de datos ya habia sido creada");
                    }
                    break;
                    //AGREGAR
                case 2:
                    if(bdUsuariosCatEmpleadoCreado){
                        if(cantidadUsuariosCatEmpleado< Usuarios.length){
                            bdUsuariosCatEmpleadoGuardados = clsUsuario.FillCatalogoPersonaDB(Usuarios, cantidadUsuariosCatEmpleado);
                            if (bdUsuariosCatEmpleadoGuardados) {
                                cantidadUsuariosCatEmpleado++;
                                utl.ShowMsg("El empleado se agregó correctamente");
                            }
                        }else{utl.ShowMsg("Error, se a exedido el numero de datos en Base de datos");}
                    }else{utl.ShowMsg("Error, la base de datos aun no a sido creada");}
                    
                    break;
                    //EDITAR
                case 3:
                    if(!bdUsuariosCatEmpleadoCreado){ utl.ShowMsg("Error, la base de datos aun no existe"); return Usuarios; };
                    if (cantidadUsuariosCatEmpleado == 0) {
                        utl.ShowMsg("Primero debe agregar empleado en la base de datos");
                    }
                    else{
                        //0 - error
                        //1 - editado
                        //2 - no encontrado
                       int respuesta = clsUsuario.editarPersona(Usuarios, cantidadUsuariosCatEmpleado);
                        if (respuesta == 0) {
                            utl.ShowMsg("Error al editar el empleado");
                        }else if(respuesta == 1){
                            utl.ShowMsg("Se ha editado el empleado.");
                        }else
                            utl.ShowMsg("No existe el empleado indicado");
                    }
                    break;
                    //INACTIVAR
                case 4:
                    if(!bdUsuariosCatEmpleadoCreado){ utl.ShowMsg("Error, la base de datos aun no existe"); return Usuarios; };
                        if (cantidadUsuariosCatEmpleado == 0) {
                            utl.ShowMsg("Debe agregar un empleado");
                        }
                        else{
                            int mensj = clsUsuario.InactivarPersona(Usuarios, cantidadUsuariosCatEmpleado);
                             if (mensj == 0) {
                                utl.ShowMsg("Error al eliminar el empleado");
                            }else if(mensj == 1){
                                cantidadUsuariosCatEmpleado--;
                                utl.ShowMsg("Se ha eliminado el empleado.");

                            }else
                                utl.ShowMsg("No se encontró el empleado");       
                        }
                    break;
                case 0:
                    break;
                default:
                    utl.ShowMsg("Error, el valor ingresado no es una opcion valida.");
                    break;       
            }
        }while(opcion != 0);
        
        return Usuarios;
    }
    public static clsCatalogoPersona[] MenuCatalogoClientes(clsCatalogoPersona[] Usuarios){
        Utilities utl = new Utilities();
        clsCatalogoPersona clsUsuario = new clsCatalogoPersona();
       
        int opcion = 0;
        
        do{
            opcion = utl.InputInt("Catalogo Clientes \n 1-Crear Base de datos \n 2- Agregar Clientes \n 3- Editar Clientes \n 4- Inactivar Clientes \n 0-Salir");
            switch(opcion){
                //CREAR
                case 1:
                    if(bdUsuariosCatClientesCreado == false){
                        Usuarios = clsUsuario.generarBDCatalogoPersona();
                        bdUsuariosCatClientesCreado = true;
                    }else{
                        utl.ShowMsg("Error, la base de datos ya habia sido creada");
                    }
                    
                    break;
                    //AGREGAR
                case 2:
                    if(bdUsuariosCatClientesCreado){
                        if(cantidadUsuariosCatClientes< Usuarios.length){
                            bdUsuariosCatClientesGuardados = clsUsuario.FillCatalogoPersonaDB(Usuarios, cantidadUsuariosCatClientes);
                            if (bdUsuariosCatClientesGuardados) {
                                cantidadUsuariosCatClientes++;
                                utl.ShowMsg("El Cliente se agregó correctamente");
                            }
                        }else{utl.ShowMsg("Error, se a exedido el numero de datos en Base de datos");}
                    }else{utl.ShowMsg("Error, la base de datos aun no a sido creada");}
                    
                    break;
                    //EDITAR
                case 3:
                    if(!bdUsuariosCatClientesCreado){ utl.ShowMsg("Error, la base de datos aun no existe"); return Usuarios; };
                    if (cantidadUsuariosCatClientes == 0) {
                        utl.ShowMsg("Primero debe agregar Clientes en la base de datos");
                    }
                    else{
                        //0 - error
                        //1 - editado
                        //2 - no encontrado
                       int respuesta = clsUsuario.editarPersona(Usuarios, cantidadUsuariosCatClientes);
                        if (respuesta == 0) {
                            utl.ShowMsg("Error al editar el Cliente");
                        }else if(respuesta == 1){
                            utl.ShowMsg("Se ha editado el Cliente.");
                        }else
                            utl.ShowMsg("No existe el Cliente indicado");
                    }
                    break;
                    //INACTIVAR
                case 4:
                    if(!bdUsuariosCatClientesCreado){ utl.ShowMsg("Error, la base de datos aun no existe"); return Usuarios; };
                    if (cantidadUsuariosCatClientes == 0) {
                        utl.ShowMsg("Debe agregar un Cliente");
                    }
                    else{
                        int mensj = clsUsuario.InactivarPersona(Usuarios, cantidadUsuariosCatClientes);
                         if (mensj == 0) {
                            utl.ShowMsg("Error al eliminar el Cliente");
                        }else if(mensj == 1){
                            cantidadUsuariosCatClientes--;
                            utl.ShowMsg("Se ha eliminado el Cliente.");
                            
                        }else
                            utl.ShowMsg("No se encontró el Cliente");       
                    }
                    break;
                case 0:
                    break;
                default:
                    utl.ShowMsg("Error, el valor ingresado no es una opcion valida.");
                    break;       
            }
        }while(opcion != 0);
        
        return Usuarios;
    }
    public static clsCatalogoCategoriaProductos[] MenuCatalogoCatProductos(clsCatalogoCategoriaProductos[] Usuarios){
        Utilities utl = new Utilities();
        clsCatalogoCategoriaProductos clsUsuario = new clsCatalogoCategoriaProductos();
       
        int opcion = 0;
        
        do{
            opcion = utl.InputInt("Catalogo Categorias \n 1-Crear Base de datos \n 2- Agregar Categorias \n 3- Editar Categorias \n 4- Inactivar Categorias \n 0-Salir");
            switch(opcion){
                //CREAR
                case 1:
                    if(bdUsuariosCatCategProductosCreado == false){
                        Usuarios = clsUsuario.generarBDCatalogoProductos();
                        bdUsuariosCatCategProductosCreado = true;
                    }else{
                        utl.ShowMsg("Error, la base de datos ya habia sido creada");
                    }
                    break;
                    //AGREGAR
                case 2:
                    if(bdUsuariosCatCategProductosCreado){
                        if(cantidadUsuariosCatCategProductos< Usuarios.length){
                            bdUsuariosCatCategProductosGuardados = clsUsuario.FillCatalogoCategoriaPDB(Usuarios, cantidadUsuariosCatCategProductos);
                            if (bdUsuariosCatCategProductosGuardados) {
                                cantidadUsuariosCatCategProductos++;
                                utl.ShowMsg("La Categoria se agregó correctamente");
                            }
                        }else{utl.ShowMsg("Error, se a exedido el numero de datos en Base de datos");}
                    }else{utl.ShowMsg("Error, la base de datos aun no a sido creada");}
                    
                    break;
                    //EDITAR
                case 3:
                    if (cantidadUsuariosCatCategProductos == 0) {
                        utl.ShowMsg("Primero debe agregar Categorias en la base de datos");
                    }
                    else{
                        //0 - error
                        //1 - editado
                        //2 - no encontrado
                       int respuesta = clsUsuario.editarCategoriaProductos(Usuarios, cantidadUsuariosCatCategProductos);
                        if (respuesta == 0) {
                            utl.ShowMsg("Error al editar la categoria");
                        }else if(respuesta == 1){
                            utl.ShowMsg("Se ha editado la categoria.");
                        }else
                            utl.ShowMsg("No existe la categoria indicada");
                    }
                    break;
                    //INACTIVAR
                case 4:
                    if (cantidadUsuariosCatCategProductos == 0) {
                        utl.ShowMsg("Debe agregar una categoria");
                    }
                    else{
                        int mensj = clsUsuario.InactivarCategoriaProductos(Usuarios, cantidadUsuariosCatCategProductos);
                         if (mensj == 0) {
                            utl.ShowMsg("Error al eliminar la categoria");
                        }else if(mensj == 1){
                            cantidadUsuariosCatCategProductos--;
                            utl.ShowMsg("Se ha eliminado la categoria.");
                            
                        }else
                            utl.ShowMsg("No se encontró la categoria");       
                    }
                    break;
                case 0:
                    break;
                default:
                    utl.ShowMsg("Error, el valor ingresado no es una opcion valida.");
                    break;       
            }
        }while(opcion != 0);
        
        return Usuarios;
    }
    public static clsCatalogoProductos[] MenuCatalogoProductos(clsCatalogoProductos[] Usuarios, clsCatalogoCategoriaProductos[] Categorias){
        Utilities utl = new Utilities();
        clsCatalogoProductos clsUsuario = new clsCatalogoProductos();
        if(Categorias.length < 1){
            utl.ShowMsg("Error, necesita tener Categorias creadas para generar un Producto");
            return Usuarios;
        }
       
        int opcion = 0;
        
        do{
            opcion = utl.InputInt("Catalogo Productos \n 1-Crear Base de datos \n 2- Agregar Productos \n 3- Editar Productos \n 4- Inactivar Productos \n 0-Salir");
            switch(opcion){
                //CREAR
                case 1:
                    if(bdUsuariosCatProductosCreado == false){
                        Usuarios = clsUsuario.generarBDCatalogoProductos();
                        bdUsuariosCatProductosCreado = true;
                    }else{
                        utl.ShowMsg("Error, la base de datos ya habia sido creada");
                    }
                    
                    break;
                    //AGREGAR
                case 2:
                    if(bdUsuariosCatProductosCreado){
                        if(cantidadUsuariosCatProductos< Usuarios.length){
                            bdUsuariosCatProductosGuardados = clsUsuario.FillCatalogoCategoriaDB(Usuarios, cantidadUsuariosCatProductos, Categorias);
                            if (bdUsuariosCatProductosGuardados) {
                                cantidadUsuariosCatProductos++;
                                utl.ShowMsg("El Producto se agregó correctamente");
                            }
                        }else{utl.ShowMsg("Error, se a exedido el numero de datos en Base de datos");}
                    }else{utl.ShowMsg("Error, la base de datos aun no a sido creada");}
                    
                    break;
                    //EDITAR
                case 3:
                    if (cantidadUsuariosCatProductos == 0) {
                        utl.ShowMsg("Primero debe agregar Productos en la base de datos");
                    }
                    else{
                        //0 - error
                        //1 - editado
                        //2 - no encontrado
                       int respuesta = clsUsuario.editarCategoriaProductos(Usuarios, cantidadUsuariosCatProductos,Categorias);
                        if (respuesta == 0) {
                            utl.ShowMsg("Error al editar el Producto");
                        }else if(respuesta == 1){
                            utl.ShowMsg("Se ha editado el Producto.");
                        }else
                            utl.ShowMsg("No existe el Producto indicado");
                    }
                    break;
                    //INACTIVAR
                case 4:
                    if (cantidadUsuariosCatProductos == 0) {
                        utl.ShowMsg("Debe agregar un Producto");
                    }
                    else{
                        int mensj = clsUsuario.InactivarCategoriaProductos(Usuarios, cantidadUsuariosCatProductos);
                         if (mensj == 0) {
                            utl.ShowMsg("Error al eliminar el Producto");
                        }else if(mensj == 1){
                            cantidadUsuariosCatProductos--;
                            utl.ShowMsg("Se ha eliminado el Producto.");
                            
                        }else
                            utl.ShowMsg("No se encontró el Producto");       
                    }
                    break;
                case 0:
                    break;
                default:
                    utl.ShowMsg("Error, el valor ingresado no es una opcion valida.");
                    break;       
            }
        }while(opcion != 0);
        
        return Usuarios;
    }
    public static clsFacturas[] MenuFacturas(clsFacturas[] Usuarios,clsCatalogoProductos[] productos ,clsCatalogoPersona[] Cliente, clsCatalogoPersona[] Empleado ){
        Utilities utl = new Utilities();
        clsFacturas clsUsuario = new clsFacturas();
        
        if(productos.length == 0 || Cliente.length == 0 || Empleado.length == 0){
            utl.ShowMsg("Error, debe tener datos generados en productos, Catologo clientes y Catalogo Empleados antes de poder continuar!");
            return Usuarios;
        }
        
        
       
        int opcion = 0;
        
        do{
            opcion = utl.InputInt("FACTURAS \n 1-Crear Base de datos \n 2- Crear Factura \n 3- Eliminar Factura \n 0-Salir");
            switch(opcion){
                //CREAR
                case 1:
                    if(bdFacturaCreado == false){
                        Usuarios = clsUsuario.generarBDFacturas();
                        bdFacturaCreado = true;
                    }else{
                        utl.ShowMsg("Error, la base de datos ya habia sido creada");
                    }
                    
                    break;
                    //AGREGAR
                case 2:
                    if(bdFacturaCreado){
                        if(cantidadFactura< Usuarios.length){
                            bdFacturaGuardados = clsUsuario.CrearFacturaDB( Usuarios,  cantidadFactura, productos , Cliente,  Empleado );
                            if (bdFacturaGuardados) {
                                cantidadFactura++;
                                utl.ShowMsg("La factura se generó correctamente");
                            }
                        }else{utl.ShowMsg("Error, se a exedido el numero de datos en Base de datos");}
                    }else{utl.ShowMsg("Error, la base de datos aun no a sido creada");}
                    
                    break;
                    //Elimar
                case 3:
                    if (cantidadFactura == 0) {
                        utl.ShowMsg("Debe agregar una factura");
                    }
                    else{
                        int mensj = clsUsuario.InactivarFactura(Usuarios, cantidadFactura);
                         if (mensj == 0) {
                            utl.ShowMsg("Error al eliminar la factura");
                        }else if(mensj == 1){
                            cantidadUsuariosCatProductos--;
                            utl.ShowMsg("Se ha eliminado la factura.");
                            
                        }else
                            utl.ShowMsg("No se encontró el cliente");       
                    }
                    break;
                case 0:
                    break;
                default:
                    utl.ShowMsg("Error, el valor ingresado no es una opcion valida.");
                    break;       
            }
        }while(opcion != 0);
        
        return Usuarios;
    
    }
    public static String[] ImprimirIngresosDia(clsFacturas[] facturasDia, String[] ingresos){
        Utilities utl = new Utilities();
        if(!(facturasDia.length > 0)){
            utl.ShowMsg("Error, antes de continuar es necesario que existan Facturas Disponibles");
            return new String[0];
        }
        int IngresosTotales= 0;
        String imprimir = "**********INGRESOS DE EL DIA**************\n";
        for(int i = 0; i < facturasDia.length; i++){
            imprimir += "\n Factura " + (i+1) + "\n" + facturasDia[i].getFacturaTexto() + "\n";
            IngresosTotales += facturasDia[i].getMontoFactura();
        }
        imprimir += "\n Ingresos Totales = " + IngresosTotales;
    
        utl.ShowMsg(imprimir);
        ingresos = new String[]{imprimir};
        return ingresos;
    }
}
