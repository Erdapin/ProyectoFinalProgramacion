/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ericks.nuevoproyectofinal;

import java.awt.TextArea;
import javax.swing.JOptionPane;

/**
 *
 * @author Erick
 */
public class Utilities {
     //Obtiene mensaje
    public void ShowMsg(String msg){
       JOptionPane.showMessageDialog(null,msg);
    }
    
    public void ShowMsg(TextArea msg){
       JOptionPane.showMessageDialog(null,msg);
    }
    
    //Obtiene Int
    public int InputInt(String msg){
        try{
            int x = Integer.parseInt(JOptionPane.showInputDialog(null,msg));
            return x;
        }
        catch(Exception ex){
            ShowMsg("Error, el valor ingresado no es valido vuelvalo a intentar");
            return InputInt(msg);
        }
    }
    
    //Obtiene String
    public String InputString(String msg){
        return JOptionPane.showInputDialog(null,msg);
    }
}
