/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ericks.nuevoproyectofinal;

import java.awt.TextArea;

/**
 *
 * @author Erick
 */
public class clsUsuarios {
    Utilities utl = new Utilities();
    private String nombre;
    private String apellidos;
    private String usuario;
    private String contrasena;
   
    
    public clsUsuarios(String nombre,String apellidos,String usuario, String contrasena){
        this.nombre = nombre;
        this.apellidos= apellidos;
        this.usuario = usuario;
        this.contrasena = contrasena;
        
    }
    
    public clsUsuarios(){
    }
    
    public clsUsuarios[] generarBDUsuarios() {
        int tamano = utl.InputInt("Digite la cantidad de usuarios de la base de datos Usuarios: ");
        clsUsuarios usuarios[] = new clsUsuarios[tamano];
        return usuarios;
    }
    
     public boolean FillUsuariosDB(clsUsuarios Usuarios[], int Cantidad) {
        
        String nombre = utl.InputString("Digite el nombre");
        String apellidos = utl.InputString("Digite los apellidos");
        String usuario = utl.InputString("Digite un nombre de usuario");
        String contrasena = utl.InputString("Digite una contraseña");
        
        
        clsUsuarios Usuario = new clsUsuarios(nombre, apellidos, usuario, contrasena);
        Usuarios[Cantidad] = Usuario;

        return true;
    }
     
     
     
     public int InactivarUsuario(clsUsuarios Usuarios[], int Cantidad) {
        String buscarNickname = utl.InputString("Digite el nickname de el usuario que desea eliminar");
        int buscarInd = -1;
        for (int i = 0; i < Cantidad; i++) {
            if (Usuarios[i].getUsuario().equalsIgnoreCase(buscarNickname)) {
                buscarInd = i;
                break;
            }
        }
        if (buscarInd == -1) {
            return 2;
        } else {
            for (int i = buscarInd; i < Cantidad-1; i++) {
                Usuarios[i] = Usuarios[i+1];
            }
            Usuarios[Cantidad-1] = null;
            return 1;
        }

    }

    public int editarUsuario(clsUsuarios Usuarios[], int cantP) {
        //0 - error
        //1 -  edición
        //2 - no encontro nada
        String usuarioFound = utl.InputString("Digite el nickname de el usuario que desea buscar");
        int Buscar = -1;
        for (int i = 0; i < cantP; i++) {
            if (Usuarios[i].getUsuario().equalsIgnoreCase(usuarioFound)) {
                Buscar = i;
                break;
            }
        }
        if (Buscar == -1) {
            return 2;
        } else {
            int opcion = 5;
            do {
                opcion = utl.InputInt("Que desea editar? \n 1- Nombre \n 2- Apellido \n 3-Usuario \n 4-Contraseña \n 5- Salir");
                switch (opcion) {
                    case 1:
                        Usuarios[Buscar].setNombre(utl.InputString("Escriba un nuevo nombre"));
                        break;
                    case 2:
                        Usuarios[Buscar].setApellidos(utl.InputString("Escriba nuevos apellidos"));
                        break;
                    case 3:
                        Usuarios[Buscar].setUsuario(utl.InputString("Escriba el nuevo nombre de usuario (Nickname)"));
                        break;
                    case 4:
                        Usuarios[Buscar].setContrasena(utl.InputString("Escriba una nueva contraseña"));
                        break;
                    case 5:
                        break;
                    default:
                        utl.ShowMsg("Error, el valor ingresado no es valido, intente de nuevo");
                        break;
                }

            } while (opcion != 5);
            return 1;
        }
    }

    public void VerTodosUsuarios(clsUsuarios Usuarios[], int cantidad) {
        String imprimir = "Nombre\tApellidos\tUsuarios\tContraseña\n";
        for (int i = 0; i < cantidad; i++) {
            imprimir += Usuarios[i].toString() + "\n";
        }
        utl.ShowMsg(new TextArea(imprimir));
    }
    
    public void ConsultarUsuario(clsUsuarios usuarios[], int cantidad){
    String buscar = utl.InputString("Escriba el nickname o el nombre de el usuario a mostrar");
        int index = -1;
        for (int i = 0; i < cantidad; i++) {
            if (usuarios[i].getUsuario().equalsIgnoreCase(buscar) ||usuarios[i].getNombre().equalsIgnoreCase(buscar) ) {
                index = i;
                break;
            }
        }
        if (index == -1) {
            utl.ShowMsg("No se encontro un usuario");
        } else {
            utl.ShowMsg("Nombre: " + usuarios[index].getNombre() + "\nNombre: "+usuarios[index].getApellidos() + "\nApellidos: "+usuarios[index].getUsuario()+ "\nEdad: "+usuarios[index].getContrasena());
        }
    }
    
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

}
