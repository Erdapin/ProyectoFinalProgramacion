/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ericks.nuevoproyectofinal;

import java.awt.TextArea;

/**
 *
 * @author Erick
 */
public class clsCatalogoProductos {

    
   
    
    Utilities utl = new Utilities();
    private String descripcion;
    private String categoria;
    private int cantidad;
    private int precioU;
    private String fechaVencimiento;
    
  
    public clsCatalogoProductos(String descripcion,String categoria,int cantidad,int precioU, String fechaV){
        this.descripcion = descripcion;
        this.categoria = categoria;
        this.cantidad = cantidad;
        this.precioU = precioU;
        this.fechaVencimiento = fechaV;
    }
    
    public clsCatalogoProductos(){
    }
    
    public clsCatalogoProductos[] generarBDCatalogoProductos() {
        int tamano = utl.InputInt("Digite la cantidad de Catalogos de la base de datos: ");
        clsCatalogoProductos usuarios[] = new clsCatalogoProductos[tamano];
        return usuarios;
    }
    
     public boolean FillCatalogoCategoriaDB(clsCatalogoProductos Usuarios[], int Cantidad, clsCatalogoCategoriaProductos[] categorias) {
        
        if(categorias.length == 0){
            utl.ShowMsg("Error, no hay categorias dispibles"); 
            return false;
        }
        
         
        String descripcion = utl.InputString("Digite el nombre de el producto");
        
        String CategoriasDisp = "";
        int max = 0;
        for(int i=0; categorias.length > i; i++){
            max ++;
            CategoriasDisp += i +"-"+categorias[i].getNombreCategoria() + "\n";
        } 
        
        String nombreCat;
        boolean valido = false;
        do{
            int categoria = utl.InputInt(CategoriasDisp + " Digite la categoria de el producto deseada:");
            if(categoria>max || categoria < 0){
                utl.ShowMsg("La categoria no existe en la base de datos vuelvalo a intentar");
                return false;
            }else{
               nombreCat =  categorias[categoria].getNombreCategoria();
               valido = true;
            }

        }while(valido != true);
        int cantidad = utl.InputInt("Digite la cantidad disponible");
        int precioU = utl.InputInt("Ingrese el precio por unidad");
        String FechaV = utl.InputString("Digite la Fecha de vencimiento");
        
        
        clsCatalogoProductos Usuario = new clsCatalogoProductos(descripcion, categoria,cantidad, precioU,FechaV );
        Usuarios[Cantidad] = Usuario;

        return true;
    }

     public int InactivarCategoriaProductos(clsCatalogoProductos Usuarios[], int Cantidad) {
        String nombrebuscar = utl.InputString("Digite la descripcion de el producto que desea inhabilitar");
        int buscarInd = -1;
        for (int i = 0; i < Cantidad; i++) {
            if (Usuarios[i].getDescripcion().equalsIgnoreCase(nombrebuscar)) {
                buscarInd = i;
                break;
            }
        }
        if (buscarInd == -1) {
            return 2;
        } else {
            for (int i = buscarInd; i < Cantidad-1; i++) {
                Usuarios[i] = Usuarios[i+1];
            }
            Usuarios[Cantidad-1] = null;
            return 1;
        }

    }

    public int editarCategoriaProductos(clsCatalogoProductos Usuarios[], int cantP, clsCatalogoCategoriaProductos[] categorias) {
        //0 - error
        //1 -  edición
        //2 - no encontro nada
        String catalogoFound = utl.InputString("Digite la descripcion del producto que desea buscar");
        int Buscar = -1;
        for (int i = 0; i < cantP; i++) {
            if (Usuarios[i].getDescripcion().equalsIgnoreCase(catalogoFound)) {
                Buscar = i;
                break;
            }
        }
        if (Buscar == -1) {
            return 2;
        } else {
            int opcion = 3;
            do {
                opcion = utl.InputInt("Que desea editar? \n 1- Descripcion \n 2- categoria \n 3-cantidad \n 4- precio por Unidad \n "+
                        "5- Fecha de vencimiento");
                switch (opcion) {
                    case 1:
                        Usuarios[Buscar].setDescripcion(utl.InputString("Escriba un nuevo nombre para la categoria"));
                        break;
                    case 2:
                        
                        boolean existe= false;
                        String NewCat ="";
                        
                        do{
                            NewCat = utl.InputString("Digite una nueva categoria para el producto (0 para salir)");
                            for(int i= 0; i<= categorias.length ; i++){
                                if(NewCat == categorias[i].getNombreCategoria()){
                                    existe= true;
                                }
                            }
                            if(existe== false){
                                utl.ShowMsg("La categoria no existe en la base de datos vuelvalo a intentar");
                            }
                            if(NewCat == "0"){
                                return 2;
                            }
                        }while(existe != true);
                        Usuarios[Buscar].setCategoria(NewCat);
                        break;
                    case 3:
                        Usuarios[Buscar].setCantidad(utl.InputInt("Digite una nueva cantidad para el producto"));
                        break;
                    case 4:
                        Usuarios[Buscar].setPrecioU(utl.InputInt("Digite un nuevo precio para el producto"));
                        break;
                    case 5:
                        Usuarios[Buscar].setFechaVencimiento(utl.InputString("Escriba la nueva fecha de vencimiento"));
                        break;
                    default:
                        utl.ShowMsg("Error, el valor ingresado no es valido, intente de nuevo");
                        break;
                }

            } while (opcion != 3);
            return 1;
        }
    }

    public void VerTodosCategoriaProductos(clsCatalogoProductos Usuarios[], int cantidad) {
        String imprimir = "Descripcion\tCategoria\tCantidad\tPrecio\tFechaVencimiento\t";
        for (int i = 0; i < cantidad; i++) {
            imprimir += Usuarios[i].toString() + "\n";
        }
        utl.ShowMsg(new TextArea(imprimir));
    }
    
    public void ConsultarCategoriaProductos(clsCatalogoProductos usuarios[], int cantidad){
    String buscar = utl.InputString("Escriba la descripcion de el producto a buscar");
        int index = -1;
        for (int i = 0; i < cantidad; i++) {
            if (usuarios[i].getDescripcion().equalsIgnoreCase(buscar)) {
                index = i;
                break;
            }
        }
        if (index == -1) {
            utl.ShowMsg("No se encontro un usuario");
        } else {
            utl.ShowMsg("descripcion: "+usuarios[index].getDescripcion()+ "\nCategoria: "+usuarios[index].getCategoria()+"\nCantidad: "+usuarios[index].getCantidad()+"\nPrecio: "+usuarios[index].getPrecioU()+ "\n" + usuarios[index].getFechaVencimiento());
        }
    }
    
    
    
    
     public String getDescripcion() {
        return descripcion;
    }

    
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getCategoria() {
        return categoria;
    }

    
    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

   
    public int getCantidad() {
        return cantidad;
    }

   
    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

   
    public long getPrecioU() {
        return precioU;
    }

    
    public void setPrecioU(int precioU) {
        this.precioU = precioU;
    }

    
    public String getFechaVencimiento() {
        return fechaVencimiento;
    }

    
    public void setFechaVencimiento(String fechaVencimiento) {
        this.fechaVencimiento = fechaVencimiento;
    }
    
   
  
}
