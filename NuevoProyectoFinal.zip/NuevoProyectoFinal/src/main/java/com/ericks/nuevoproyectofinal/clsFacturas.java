/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ericks.nuevoproyectofinal;


public class clsFacturas {
    
    Utilities utl = new Utilities();
    private String fechaFactura;
    private int montoFactura;
    private String nombreCliente;
    private String facturaTexto;
    
    public clsFacturas(String fechaFactura,int montoFactura ,String nombreCliente, String facturaTexto){
        this.fechaFactura = fechaFactura;
        this.montoFactura = montoFactura;
        this.nombreCliente = nombreCliente;
        this.facturaTexto = facturaTexto;
    }
    public clsFacturas(){}
    
    public clsFacturas[] generarBDFacturas() {
        int tamano = utl.InputInt("Digite la cantidad de Facturas de la base de datos: ");
        clsFacturas usuarios[] = new clsFacturas[tamano];
        return usuarios;
    }
     
    public boolean CrearFacturaDB(clsFacturas Usuarios[], int Cantidad,clsCatalogoProductos[] productos ,clsCatalogoPersona[] Cliente,clsCatalogoPersona[] Empleado) {
        
        String fechaFactura = utl.InputString("Digite la fecha de la factura: ");
        
        //Obtiene los productos para el string
        String ProductosDisp = "Productos disponibles:\n";
        int Max = productos.length;
        for(int i = 0; i< productos.length ; i++){
            ProductosDisp += "\n " +(i) + "- Nombre: " +productos[i].getDescripcion() + "  Precio: " + productos[i].getPrecioU();
            
        }
        int opcion = 0;
        boolean validar = false;
        int precioTotal = 0;
        String ProductosComprar = "";
        do{
            opcion = utl.InputInt(ProductosDisp + "\n Cual producto desea agregar?");
            
            if(productos[opcion]==null){
                utl.ShowMsg("Un errror ha ocurrido, no se a podido obtener el producto solicitado");
                return false;
            }
            if(opcion > Max || opcion<0){
                utl.ShowMsg("Error, no elegiste una opcion correcta.");
                return false;
            }else{
            ProductosComprar += "\n - Nombre: " +productos[opcion].getDescripcion() + "  Precio: " + productos[opcion].getPrecioU();
            precioTotal += productos[opcion].getPrecioU();
            validar = true;
            }
        }while(validar != true);
        
        int montoFactura = precioTotal;
        
        String opcionCliente = "Opciones Cliente :";
        boolean ClienteEncontrado = false;
        int cantidadCliente = Cliente.length - 1;
        for(int j = 0; j< Cliente.length; j++ ){
            opcionCliente += j +"-"+ Cliente[j].getNombre()+ "\n";
        }
        int codnombreCliente = utl.InputInt(opcionCliente);
        if(codnombreCliente < 0 || codnombreCliente>cantidadCliente){
            utl.ShowMsg("Error, el valor ingresado no corresponde con un cliente!");
            return false;
        }
        if(Cliente[codnombreCliente].getNombre() == null){
            utl.ShowMsg("Ha ocurrido un error inesperado.");
            return false;
        }
        
        
        String nombreCliente = Cliente[codnombreCliente].getNombre();
        
        String opcionEmpleado = "Opciones Empleado :";
        
        int cantidadEmpleado = Empleado.length - 1;
        for(int j = 0; j< Empleado.length; j++ ){
            opcionEmpleado += j +"-"+ Empleado[j].getNombre()+ "\n";
        }
        int codnombreEmpleado = utl.InputInt(opcionEmpleado);
        if(codnombreEmpleado < 0 || codnombreEmpleado> cantidadEmpleado){
            utl.ShowMsg("Error, el valor ingresado no corresponde con un Empleado!");
            return false;
        }
        if(Empleado[codnombreEmpleado].getNombre() == null){
            utl.ShowMsg("Ha ocurrido un error inesperado.");
            return false;
        }
        
        String nombreEmpleado = Empleado[codnombreEmpleado].getNombre();
        
        String facturaTexto = "*******FACTURA******\n"+
                              ProductosComprar +"\n"+ "Precio Total: " + montoFactura +"\n"+
                              "Cliente: " + nombreCliente + "\n Empleado: " + nombreEmpleado +
                               "\n*******************";
        
        
        clsFacturas Usuario = new clsFacturas(fechaFactura, montoFactura, nombreCliente, facturaTexto);
        Usuarios[Cantidad] = Usuario;

        return true;
    }
    
    public int InactivarFactura(clsFacturas Usuarios[], int Cantidad) {
        String Opciones ="Opciones:?\n";
        int cantidadUs = Usuarios.length - 1;
        for(int i=0; i<Usuarios.length ; i++){
            Opciones += i +"-"+ Usuarios[i].getNombreCliente()+"\n";
        }
        
        int nombreSelect = utl.InputInt( Opciones + "Digite el numero del cliente de la factura que desea inhabilitar");
        
        if(nombreSelect < 0 || nombreSelect > cantidadUs){
            utl.ShowMsg("Error, el valor ingresado no corresponde con un Empleado!");
            return -1;
        }
        
        String nombre =  Usuarios[nombreSelect].getNombreCliente();
        
        
        
        int buscarInd = -1;
        for (int i = 0; i < Cantidad; i++) {
            if (Usuarios[i].getNombreCliente().equalsIgnoreCase(nombre)) {
                buscarInd = i;
                break;
            }
        }
        if (buscarInd == -1) {
            return 2;
        } else {
            for (int i = buscarInd; i < Cantidad-1; i++) {
                Usuarios[i] = Usuarios[i+1];
            }
            Usuarios[Cantidad-1] = null;
            return 1;
        }

    }
    
    
    public String getFechaFactura() {
        return fechaFactura;
    }
    public void setFechaFactura(String fechaFactura) {
        this.fechaFactura = fechaFactura;
    }
    public int getMontoFactura() {
        return montoFactura;
    }
    public void setMontoFactura(int montoFactura) {
        this.montoFactura = montoFactura;
    }
    public String getNombreCliente() {
        return nombreCliente;
    }
    public void setNombreCliente(String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }
    public String getFacturaTexto() {
        return facturaTexto;
    }
    public void setFacturaTexto(String facturaTexto) {
        this.facturaTexto = facturaTexto;
    }
    

}
