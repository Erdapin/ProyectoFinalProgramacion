/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ericks.nuevoproyectofinal;

import java.awt.TextArea;

/**
 *
 * @author Erick
 */
public class clsCatalogoPersona {

    
    Utilities utl = new Utilities();
    private String nombre;
    private String apellidos;
    private String ciudad;
    private String direccion;
    private int telefono;
    private String email;
  
    public clsCatalogoPersona(String nombre,String apellidos,String ciudad, String direccion, int telefono, String email){
        this.nombre = nombre;
        this.apellidos= apellidos;
        this.ciudad = ciudad;
        this.direccion = direccion;
        this.telefono = telefono;
        this.email = email;
    }
    
    public clsCatalogoPersona(){
    }
    
    public clsCatalogoPersona[] generarBDCatalogoPersona() {
        int tamano = utl.InputInt("Digite la cantidad de personas para la base de datos: ");
        clsCatalogoPersona usuarios[] = new clsCatalogoPersona[tamano];
        return usuarios;
    }
    
     public boolean FillCatalogoPersonaDB(clsCatalogoPersona Usuarios[], int Cantidad) {
        
        String nombre = utl.InputString("Digite el nombre");
        String apellidos = utl.InputString("Digite los apellidos");
        String ciudad = utl.InputString("Digite la ciudad de la persona");
        String direccion = utl.InputString("Digite la direccion de la persona");
        int telefono = utl.InputInt("Digite el numero de telefono");
        String email = utl.InputString("Digite el email de la persona");
        clsCatalogoPersona Usuario = new clsCatalogoPersona(nombre, apellidos, ciudad, direccion, telefono, email);
        Usuarios[Cantidad] = Usuario;

        return true;
    }
     
     
     
     public int InactivarPersona(clsCatalogoPersona Usuarios[], int Cantidad) {
        String nombrebuscar = utl.InputString("Digite el nombre de la persona que desea inhabilitar");
        int buscarInd = -1;
        for (int i = 0; i < Cantidad; i++) {
            if (Usuarios[i].getNombre().equalsIgnoreCase(nombrebuscar)) {
                buscarInd = i;
                break;
            }
        }
        if (buscarInd == -1) {
            return 2;
        } else {
            for (int i = buscarInd; i < Cantidad-1; i++) {
                Usuarios[i] = Usuarios[i+1];
            }
            Usuarios[Cantidad-1] = null;
            return 1;
        }

    }

    public int editarPersona(clsCatalogoPersona Usuarios[], int cantP) {
        //0 - error
        //1 -  edición
        //2 - no encontro nada
        String usuarioFound = utl.InputString("Digite el nombre de la persona que desea buscar");
        int Buscar = -1;
        for (int i = 0; i < cantP; i++) {
            if (Usuarios[i].getNombre().equalsIgnoreCase(usuarioFound)) {
                Buscar = i;
                break;
            }
        }
        if (Buscar == -1) {
            return 2;
        } else {
            int opcion = 7;
            do {
                opcion = utl.InputInt("Que desea editar? \n 1- Nombre \n 2- Apellido \n 3-Ciudad \n 4-direccion \n 5- telefono\n 6- email \n 7-Salir");
                switch (opcion) {
                    case 1:
                        Usuarios[Buscar].setNombre(utl.InputString("Escriba un nuevo nombre"));
                        break;
                    case 2:
                        Usuarios[Buscar].setApellidos(utl.InputString("Escriba nuevos apellidos"));
                        break;
                    case 3:
                        Usuarios[Buscar].setCiudad(utl.InputString("Escriba la nueva ciudad de la persona"));
                        break;
                    case 4:
                        Usuarios[Buscar].setDireccion(utl.InputString("Escriba una nueva direccion"));
                        break;
                    case 5:
                        Usuarios[Buscar].setTelefono(utl.InputInt("Escriba un nuevo numero de telefono"));
                        break;
                    case 6:
                        Usuarios[Buscar].setEmail(utl.InputString("Escriba un nuevo email"));
                        break;
                    
                    case 7:
                        break;
                    default:
                        utl.ShowMsg("Error, el valor ingresado no es valido, intente de nuevo");
                        break;
                }

            } while (opcion != 7);
            return 1;
        }
    }

    public void VerTodosPersonas(clsCatalogoPersona Usuarios[], int cantidad) {
        String imprimir = "Nombre\tApellidos\tCiudad\tdireccion\ntelefono\nemail\n";
        for (int i = 0; i < cantidad; i++) {
            imprimir += Usuarios[i].toString() + "\n";
        }
        utl.ShowMsg(new TextArea(imprimir));
    }
    
    public void ConsultarPersona(clsCatalogoPersona usuarios[], int cantidad){
    String buscar = utl.InputString("Escriba el nombre de la persona a buscar");
        int index = -1;
        for (int i = 0; i < cantidad; i++) {
            if (usuarios[i].getNombre().equalsIgnoreCase(buscar)) {
                index = i;
                break;
            }
        }
        if (index == -1) {
            utl.ShowMsg("No se encontro un usuario");
        } else {
            utl.ShowMsg("Nombre: "+usuarios[index].getNombre() + "\nApellidos: "+usuarios[index].getApellidos() + "\nCiudad: "+usuarios[index].getCiudad()+ "\nDireccion: "+usuarios[index].getDireccion() + "\nTelefono:"+usuarios[index].getTelefono() + "\nEmail:"+usuarios[index].getEmail());
        }
    }
    
    public String getNombre() {
        return nombre;
    }

    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

   
    public String getApellidos() {
        return apellidos;
    }

    
    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    
    public String getCiudad() {
        return ciudad;
    }

    
    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    
    public String getDireccion() {
        return direccion;
    }

   
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

   
    public int getTelefono() {
        return telefono;
    }

    
    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    
    public String getEmail() {
        return email;
    }

    
    public void setEmail(String email) {
        this.email = email;
    }
    
    
   
    
}
