/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ericks.nuevoproyectofinal;

import java.awt.TextArea;

/**
 *
 * @author Erick
 */
public class clsCatalogoCategoriaProductos {

    Utilities utl = new Utilities();
    private String nombreCategoria;
    private String caracteristicas;
    
  
    public clsCatalogoCategoriaProductos(String nombre,String cateristicas){
        this.nombreCategoria = nombre;
        this.caracteristicas = cateristicas;
    }
    
    public clsCatalogoCategoriaProductos(){
    }
    
    public clsCatalogoCategoriaProductos[] generarBDCatalogoProductos() {
        int tamano = utl.InputInt("Digite la cantidad de Catalogos de la base de datos: ");
        clsCatalogoCategoriaProductos usuarios[] = new clsCatalogoCategoriaProductos[tamano];
        return usuarios;
    }
    
     public boolean FillCatalogoCategoriaPDB(clsCatalogoCategoriaProductos Usuarios[], int Cantidad) {
        
        String nombreCategoria = utl.InputString("Digite el nombre de la categoria");
        String caracteristicas = utl.InputString("Digite las caracteristicas que representen la categoria");
        clsCatalogoCategoriaProductos Usuario = new clsCatalogoCategoriaProductos(nombreCategoria, caracteristicas);
        Usuarios[Cantidad] = Usuario;

        return true;
    }

     public int InactivarCategoriaProductos(clsCatalogoCategoriaProductos Usuarios[], int Cantidad) {
        String nombrebuscar = utl.InputString("Digite el nombre de la categoria que desea inhabilitar");
        int buscarInd = -1;
        for (int i = 0; i < Cantidad; i++) {
            if (Usuarios[i].getNombreCategoria().equalsIgnoreCase(nombrebuscar)) {
                buscarInd = i;
                break;
            }
        }
        if (buscarInd == -1) {
            return 2;
        } else {
            for (int i = buscarInd; i < Cantidad-1; i++) {
                Usuarios[i] = Usuarios[i+1];
            }
            Usuarios[Cantidad-1] = null;
            return 1;
        }

    }

    public int editarCategoriaProductos(clsCatalogoCategoriaProductos Usuarios[], int cantP) {
        //0 - error
        //1 -  edición
        //2 - no encontro nada
        String catalogoFound = utl.InputString("Digite el nombre del catalogo que desea buscar");
        int Buscar = -1;
        for (int i = 0; i < cantP; i++) {
            if (Usuarios[i].getNombreCategoria().equalsIgnoreCase(catalogoFound)) {
                Buscar = i;
                break;
            }
        }
        if (Buscar == -1) {
            return 2;
        } else {
            int opcion = 3;
            do {
                opcion = utl.InputInt("Que desea editar? \n 1- Nombre Categoria \n 2- Caracteristicas \n 3-Salir");
                switch (opcion) {
                    case 1:
                        Usuarios[Buscar].setNombreCategoria(utl.InputString("Escriba un nuevo nombre para la categoria"));
                        break;
                    case 2:
                        Usuarios[Buscar].setCaracteristicas(utl.InputString("Escriba las nuevas caracteristicas para la categoria"));
                        break;
                    case 3:
                        break;
                    default:
                        utl.ShowMsg("Error, el valor ingresado no es valido, intente de nuevo");
                        break;
                }

            } while (opcion != 3);
            return 1;
        }
    }

    public void VerTodosCategoriaProductos(clsCatalogoCategoriaProductos Usuarios[], int cantidad) {
        String imprimir = "Nombre\tCaracteristicas\n";
        for (int i = 0; i < cantidad; i++) {
            imprimir += Usuarios[i].toString() + "\n";
        }
        utl.ShowMsg(new TextArea(imprimir));
    }
    
    public void ConsultarCategoriaProductos(clsCatalogoCategoriaProductos usuarios[], int cantidad){
    String buscar = utl.InputString("Escriba el nombre de la categoria a buscar");
        int index = -1;
        for (int i = 0; i < cantidad; i++) {
            if (usuarios[i].getNombreCategoria().equalsIgnoreCase(buscar)) {
                index = i;
                break;
            }
        }
        if (index == -1) {
            utl.ShowMsg("No se encontro un usuario");
        } else {
            utl.ShowMsg("Nombre: "+usuarios[index].getNombreCategoria()+ "\nCategorias: "+usuarios[index].getCaracteristicas());
        }
    }
    
    public String getNombreCategoria() {
        return nombreCategoria;
    }

    
    public void setNombreCategoria(String nombreCategoria) {
        this.nombreCategoria = nombreCategoria;
    }

    
    public String getCaracteristicas() {
        return caracteristicas;
    }

   
    public void setCaracteristicas(String caracteristicas) {
        this.caracteristicas = caracteristicas;
    }
  
    
   
    
}
